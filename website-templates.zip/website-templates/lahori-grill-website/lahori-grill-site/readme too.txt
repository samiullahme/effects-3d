this is our first template.
dont use that same code as it, you can get inspirations from there.
dont use it will footer, you can make similar but footer must be also a reusable template.