# Lahori Grill & Karahi House — homepage

A responsive, single-page restaurant homepage rebuilt from the supplied visual reference. The page uses semantic HTML, plain CSS and vanilla JavaScript. No build step or framework is required.

## Run locally

1. Keep `index.html`, `styles.css` and `script.js` in the same folder.
2. Open `index.html` in a browser, or serve the folder with a local static server (recommended):

   ```bash
   python -m http.server 8000
   ```

3. Visit `http://localhost:8000`.

## Implemented interactions

- Responsive navigation and mobile menu.
- Smooth-scroll anchor navigation with active section state.
- Menu category filters.
- Add-to-order buttons, cart count and WhatsApp order message preparation.
- Favourite toggle on menu cards.
- Reservation form validation and WhatsApp message preparation.
- Mobile sticky order/reservation bar.

## Important production configuration

- The WhatsApp links intentionally use `https://wa.me/?text=...` without a hard-coded phone number because the restaurant's real WhatsApp number was not provided. Replace these links with `https://wa.me/<countrycode-and-number>?text=...` when the correct number is available.
- The reservation form prepares a WhatsApp request; it does not create or confirm a booking in a database. For real reservations, connect it to a booking API or backend and return an actual confirmation.
- Replace the sample address, hours, email, reviews and PKR menu prices with verified restaurant details before publishing.
- Food and restaurant images load from external image hosts. Internet access is required. Replace them with licensed, restaurant-owned image files for production deployment.

## Image source notes

- Main karahi and biryani photos: Unsplash CDN images.
- Dining room: Unsplash CDN image.
- Additional food imagery: Unsplash CDN images.
- Confirm current image licensing and terms before commercial production use. Local restaurant photography is recommended for a real restaurant site.
