(() => {
  const menuGrid = document.querySelector('#menu-grid');
  const filterButtons = [...document.querySelectorAll('[data-filter]')];
  const cartCount = document.querySelector('#cart-count');
  const toast = document.querySelector('#toast');
  const cart = new Map();
  let toastTimer;

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('is-visible');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('is-visible'), 2800);
  }

  function updateCart() {
    const count = [...cart.values()].reduce((sum, item) => sum + item.quantity, 0);
    if (cartCount) cartCount.textContent = String(count);
  }

  filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const filter = button.dataset.filter;
      filterButtons.forEach((item) => {
        const active = item === button;
        item.classList.toggle('is-active', active);
        item.setAttribute('aria-pressed', String(active));
      });
      menuGrid.querySelectorAll('.food-card').forEach((card) => {
        card.hidden = filter !== 'all' && card.dataset.category !== filter;
      });
    });
  });

  document.querySelectorAll('.add-button').forEach((button) => {
    button.addEventListener('click', () => {
      const { name, price } = button.dataset;
      const existing = cart.get(name) || { name, price: Number(price), quantity: 0 };
      existing.quantity += 1;
      cart.set(name, existing);
      updateCart();
      showToast(`${name} added to your order.`);
    });
  });

  document.querySelectorAll('.favorite-button').forEach((button) => {
    button.addEventListener('click', () => {
      const next = button.getAttribute('aria-pressed') !== 'true';
      button.setAttribute('aria-pressed', String(next));
      const cardName = button.closest('.food-card')?.querySelector('h3')?.textContent || 'Dish';
      button.setAttribute('aria-label', `${next ? 'Remove' : 'Add'} ${cardName} ${next ? 'from' : 'to'} favourites`);
      button.textContent = next ? '♥' : '♡';
      showToast(next ? `${cardName} saved to favourites.` : `${cardName} removed from favourites.`);
    });
  });

  const menuToggle = document.querySelector('.menu-toggle');
  const primaryNav = document.querySelector('.primary-nav');
  menuToggle?.addEventListener('click', () => {
    const isOpen = primaryNav.classList.toggle('is-open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
  });
  primaryNav?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
    primaryNav.classList.remove('is-open');
    menuToggle?.setAttribute('aria-expanded', 'false');
    menuToggle?.setAttribute('aria-label', 'Open navigation');
  }));

  const navLinks = [...document.querySelectorAll('.nav-link')];
  const sections = navLinks.map((link) => document.querySelector(link.getAttribute('href'))).filter(Boolean);
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          navLinks.forEach((link) => link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`));
        }
      });
    }, { rootMargin: '-30% 0px -60% 0px', threshold: 0 });
    sections.forEach((section) => observer.observe(section));
  }

  function buildOrderMessage() {
    if (cart.size === 0) return 'Hello Lahori Grill & Karahi House. I would like to see the menu and place an order.';
    const rows = [...cart.values()].map((item) => `${item.quantity} x ${item.name} — Rs ${item.price * item.quantity}`);
    const total = [...cart.values()].reduce((sum, item) => sum + item.price * item.quantity, 0);
    return `Hello Lahori Grill & Karahi House. I would like to order:\n${rows.join('\n')}\nEstimated total: Rs ${total}\nPlease confirm availability.`;
  }

  document.querySelector('#cart-open')?.addEventListener('click', () => {
    const message = encodeURIComponent(buildOrderMessage());
    window.open(`https://wa.me/?text=${message}`, '_blank', 'noopener,noreferrer');
    if (cart.size) showToast('Your order details are ready to send on WhatsApp.');
  });

  const bookingDate = document.querySelector('#booking-date');
  if (bookingDate) {
    const today = new Date();
    const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    bookingDate.min = localDate;
  }

  document.querySelector('#reservation-form')?.addEventListener('submit', (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const data = new FormData(form);
    const message = [
      'Hello Lahori Grill & Karahi House. I would like to request a table reservation.',
      `Name: ${data.get('name')}`,
      `Date: ${data.get('date')}`,
      `Time: ${data.get('time')}`,
      `Guests: ${data.get('guests')}`,
      'Please confirm whether this time is available.'
    ].join('\n');
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer');
    showToast('Reservation request prepared. Send it on WhatsApp to contact the restaurant.');
  });

  const year = document.querySelector('#current-year');
  if (year) year.textContent = String(new Date().getFullYear());
})();
